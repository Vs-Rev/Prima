export var FudgeNet: any;
